# IONIX_Halloween
Game code with other files required for the tile builder game

-->The game has a base menu that consists of start and end options to choose
-->The game starts in the first level to seven levels
-->There are a few hurdles such as the halo-pumpkin and the lava pool.
-->Hitting them kills the halo boy and again restart the game from that lost level.
